import pandas as pd

# User-defined parameters
PARAMS = {
    "input_file": r'C:\Users\ARohilla\Tech Titans\Processed_Data.xlsx',  # Output of Rule3.py
    "output_file": r'C:\Users\ARohilla\Tech Titans\Final_Output.xlsx'  # Exported output file
}

def process_rule4():
    """Process Rule4 logic based on Rule3 output."""
    # Read the input data
    df = pd.read_excel(PARAMS["input_file"], dtype=str)

    # Filter records where Rule Applied = Rule2 AND Comments = Mismatch
    filtered_df = df[(df['Rule Applied'] == 'Rule2') & (df['Comments'] == 'Mismatch')].copy()

    # Convert necessary columns to numeric for calculations
    filtered_df['Balance_Difference'] = pd.to_numeric(filtered_df['Balance_Difference'], errors='coerce').round(2)
    filtered_df['Business_date'] = pd.to_datetime(filtered_df['Business_date'], errors='coerce')

    # Group by ISIN and compare balances across dates
    result = []
    for isin, group in filtered_df.groupby('ISIN'):
        group = group.sort_values(by='Business_date')  # Sort by date
        if len(group) > 1:  # Ensure there are multiple entries for comparison
            # Calculate the sum of Balance_Difference
            balance_sum = group['Balance_Difference'].sum()
            if abs(balance_sum) < 1e-9:  # Check if the sum is effectively zero
                # Add comment to the latest date
                latest_date_idx = group['Business_date'].idxmax()
                group.loc[latest_date_idx, 'Comments'] = "Current Difference is an Offset From Previous Entry"
        result.append(group)

    # Combine all groups into a single DataFrame
    final_df = pd.concat(result)

    # Update Rule Applied to "Rule3"
    final_df['Rule Applied'] = "Rule3"

    # Export the output
    final_df.to_excel(PARAMS["output_file"], index=False)
    print(f"Final output saved to {PARAMS['output_file']}")

if __name__ == "__main__":
    process_rule4()