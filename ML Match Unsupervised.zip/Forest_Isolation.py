import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest

# User-defined parameters
PARAMS = {
    "file_path": r"C:\Users\ARohilla\Tech Titans\Synthetic_data_with_clusters.xlsx",  # Input dataset
    "output_file": r"C:\Users\ARohilla\Tech Titans\Anomaly_Detection_Output.xlsx",  # Output file path
    "contamination": 0.05,  # Proportion of anomalies in the dataset
    "scatter_plot_file": r"C:\Users\ARohilla\Tech Titans\Anomaly_Scatter_Plot.png"  # Scatter plot output file
}

def detect_anomalies():
    """Detect anomalies in the dataset using Isolation Forest."""
    # Load the dataset
    df = pd.read_excel(PARAMS["file_path"])

    # Select numeric columns for anomaly detection
    numeric_columns = df.select_dtypes(include=['float64', 'int64']).columns
    if numeric_columns.empty:
        print("No numeric columns found in the dataset for anomaly detection.")
        return

    # Prepare the data for Isolation Forest
    data = df[numeric_columns]

    # Initialize Isolation Forest
    isolation_forest = IsolationForest(contamination=PARAMS["contamination"], random_state=42)
    df['Anomaly'] = isolation_forest.fit_predict(data)

    # Add a column to indicate anomalies (1 = normal, -1 = anomaly)
    df['Anomaly_Flag'] = df['Anomaly'].apply(lambda x: 'Anomaly' if x == -1 else 'Normal')

    # Export the results to an Excel file
    df.to_excel(PARAMS["output_file"], index=False)
    print(f"Anomaly detection results saved to {PARAMS['output_file']}")

    # Plot scatter plot for the first two numeric columns
    if len(numeric_columns) >= 2:
        plt.figure(figsize=(10, 6))
        plt.scatter(
            df[numeric_columns[0]], df[numeric_columns[1]],
            c=df['Anomaly'], cmap='coolwarm', edgecolor='k', s=50
        )
        plt.title("Anomaly Detection Scatter Plot")
        plt.xlabel(numeric_columns[0])
        plt.ylabel(numeric_columns[1])
        plt.colorbar(label='Anomaly (-1 = Anomaly, 1 = Normal)')
        plt.savefig(PARAMS["scatter_plot_file"])
        plt.show()
        print(f"Scatter plot saved to {PARAMS['scatter_plot_file']}")
    else:
        print("Not enough numeric columns to create a scatter plot.")

if __name__ == "__main__":
    detect_anomalies()