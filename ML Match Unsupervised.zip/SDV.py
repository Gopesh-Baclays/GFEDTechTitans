import pandas as pd
from sdv.single_table import GaussianCopulaSynthesizer
from sdv.metadata import SingleTableMetadata
import numpy as np

# Load real dataset from an Excel file
data = pd.read_excel(r'C:\Users\ARohilla\Tech Titans\data.xlsx')  # Replace 'your_data.xlsx' with your actual file

# Create metadata for the dataset
metadata = SingleTableMetadata()
metadata.detect_from_dataframe(data)

# Initialize and train the synthesizer
synthesizer = GaussianCopulaSynthesizer(metadata)
synthesizer.fit(data)

# Generate synthetic data
synthetic_data = synthesizer.sample(num_rows=len(data))

# Add 500 additional records with a mix of all rules and 5 months of data
additional_records = synthesizer.sample(num_rows=500)

# Generate 5 months of dates starting from January 2023
months = pd.date_range(start="2023-01-01", periods=5, freq="MS")  # Generate 5 months starting from Jan 2023
additional_records['Business_date'] = np.random.choice(months, size=len(additional_records))

# Combine the original synthetic data with the additional records
final_synthetic_data = pd.concat([synthetic_data, additional_records], ignore_index=True)

# Save the final synthetic data to an Excel file
final_synthetic_data.to_excel('synthetic_data_with_added_records.xlsx', index=False)

print("Synthetic data with additional records and 5 months of data generated successfully!")