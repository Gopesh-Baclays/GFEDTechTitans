import pandas as pd

# Load Excel file
file_path =  r'C:\Users\ARohilla\Tech Titans\Data Rule2.xlsx'  # Replace with your actual file
sheet_name = 'Data'
df = pd.read_excel(file_path, sheet_name=sheet_name, dtype=str)  # Ensure ISIN is read as string

# User-selected parameters (Can be integrated with UI for dynamic selection)
selected_pair_1 = {'Reporting_id': '8080', 'GL': '12304500'}  # Replace with UI input
selected_pair_2 = {'Reporting_id': '8090', 'GL': '26850000'}  # Replace with UI input

# Filter datasets based on user-selected key pairs
df1 = df[(df['Reporting_id'] == selected_pair_1['Reporting_id']) & (df['GL'] == selected_pair_1['GL'])].copy()
df2 = df[(df['Reporting_id'] == selected_pair_2['Reporting_id']) & (df['GL'] == selected_pair_2['GL'])].copy()

# Clean ISIN column by stripping whitespace
df1['ISIN'] = df1['ISIN'].str.strip()
df2['ISIN'] = df2['ISIN'].str.strip()

# Merge datasets on the ISIN column (INNER JOIN to keep only matching records)
merged_df = pd.merge(df1, df2, on='ISIN', how='inner', suffixes=('_Src1', '_Src2'))

# Calculate balance difference
merged_df['Balance_Difference'] = pd.to_numeric(merged_df['BalanceGBP_Src1'], errors='coerce').fillna(0) - \
                                  pd.to_numeric(merged_df['BalanceGBP_Src2'], errors='coerce').fillna(0)

# Add comments based on conditions
def classify_difference(row):
    if pd.isna(row['BalanceGBP_Src1']):
        return 'Src1 Balance Missing'
    elif pd.isna(row['BalanceGBP_Src2']):
        return 'Src2 Balance Missing'
    elif row['Balance_Difference'] == 0:
        return 'Match'
    else:
        return 'Mismatch'

merged_df['Comments'] = merged_df.apply(classify_difference, axis=1)

# Select relevant columns for export
export_columns = ['ISIN', 'Reporting_id_Src1', 'GL_Src1', 'Reporting_id_Src2', 'GL_Src2', 'BalanceGBP_Src1', 'BalanceGBP_Src2', 'Balance_Difference', 'Comments']
final_df = merged_df[export_columns]

# Export the results to an Excel file
output_file = 'Rule2_results.xlsx'
final_df.to_excel(output_file, index=False)

print(f"Comparison results saved to {output_file}")