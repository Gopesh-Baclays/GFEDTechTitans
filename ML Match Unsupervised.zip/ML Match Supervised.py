import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, confusion_matrix

# Load datasets
df1 = pd.read_excel(r'C:\Users\ARohilla\Tech Titans\Data Rule 1.xlsx', sheet_name='Rule1 Source1')
df2 = pd.read_excel(r'C:\Users\ARohilla\Tech Titans\Data Rule 1.xlsx', sheet_name='Rule1 Source2')

# Merge datasets on key columns
key_columns = ['Business_date', 'Reporting_id', 'CC', 'GL', 'PC']
merged_df = pd.merge(df1, df2, on=key_columns, how='outer', suffixes=('_Src1', '_Src2'))

# Feature engineering
merged_df.fillna(0, inplace=True)
encoder = LabelEncoder()
for col in key_columns:
    merged_df[col] = encoder.fit_transform(merged_df[col])

# Create target variable based on balance difference
merged_df['Match_Label'] = (merged_df['BalanceGBP_Src1'] - merged_df['BalanceGBP_Src2']).apply(lambda x: 1 if x == 0 else 0)

# Train machine learning model
X = merged_df[key_columns]
y = merged_df['Match_Label']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = XGBClassifier()
model.fit(X_train, y_train)

# Predict matches
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Match Prediction Accuracy: {accuracy:.2f}")

# Confusion Matrix for visualization
conf_matrix = confusion_matrix(y_test, y_pred)

# Plot confusion matrix
plt.figure(figsize=(6, 5))
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=["Mismatch", "Match"], yticklabels=["Mismatch", "Match"])
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Match Prediction Confusion Matrix")
plt.show()